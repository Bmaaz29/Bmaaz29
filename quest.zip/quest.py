a=int(input())
b=int(input ())
c=int (input ())
d=a*b*c
e=a+b+c
f=d/e
print(f)

