name=input()
age=input()
address=input()
print("My Name is:",name)
print("My age is:",age)
print ("MY address is:",address) 



