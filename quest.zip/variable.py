a=10
b=10
print(a+b)



a=10
print(type(a))


a="one"
print(type(a))




a=10
b=20
c=a+b
print(c)
