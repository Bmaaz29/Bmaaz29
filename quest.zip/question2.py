name=input("enter a name:")
score=int(input("enter a score:"))
department=input("enter a department name:")

print("My name is ",name)
print("My score is",score/10,"/10")
print("My department name",department)
